<!-- Copyright 2025 The Kandinsky Team and The HuggingFace Team. All rights reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License. -->

# AutoencoderKLKVAE

The 2D variational autoencoder (VAE) model with KL loss.

The model can be loaded with the following code snippet.

```python
import torch
from diffusers import AutoencoderKLKVAE

vae = AutoencoderKLKVAE.from_pretrained("kandinskylab/KVAE-2D-1.0", subfolder="diffusers", dtype=torch.bfloat16)
```

## AutoencoderKLKVAE

[[autodoc]] AutoencoderKLKVAE
  - decode
  - all
